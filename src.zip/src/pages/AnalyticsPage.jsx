import React, { useMemo, useState } from 'react';
import { Activity, ArrowRight, BarChart3, CheckCircle2, Clock3, ShieldAlert, SlidersHorizontal, TrendingUp } from 'lucide-react';
import { Bar, BarChart, CartesianGrid, ComposedChart, Legend, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { usePortal } from '../app/PortalContext.jsx';
import { analyticsForScope, analyticsWindow } from '../data/analytics.js';
import { today } from '../data/repository.js';

function NumberCard({ icon: Icon, label, value, detail }) { return <div className="ssc-v2-stat"><div className="ssc-v2-stat-label"><span>{label}</span><Icon size={18}/></div><strong>{value}</strong><small>{detail}</small></div>; }
function ChartPanel({ title, note, children }) { return <section className="ssc-v2-panel"><div className="ssc-v2-panel-title"><h2>{title}</h2><p>{note}</p></div>{children}</section>; }
const tip = { contentStyle: { border: '1px solid #e5eaf1', borderRadius: 10, fontSize: 12, boxShadow: '0 12px 28px #1f2b3a14' } };
const axis = { fontSize: 11, fill: '#8794a6' };
const EmptyChart = ({ text = 'No records in this period.' }) => <div className="ssc-v2-chart-empty"><BarChart3 size={25}/><strong>Not enough activity yet</strong><span>{text}</span></div>;

export default function AnalyticsPage() {
  const { activeWorkspaceId, activeWorkspace, workspaces, audits, actions, scopedSites, go } = usePortal();
  const admin = activeWorkspaceId === 'admin';
  const [workspace, setWorkspace] = useState('');
  const [project, setProject] = useState('');
  const [period, setPeriod] = useState('6');
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const todayDate = today();
  const window = period === 'custom' ? { start, end } : period === 'all' ? { start: '', end: '' } : analyticsWindow(Number(period), todayDate);
  const invalid = period === 'custom' && (!start || !end || start > end || end > todayDate);
  const availableProjects = scopedSites.filter(p => !workspace || p.workspaceId === workspace);
  const sourceAudits = admin && workspace ? audits.filter(a => a.workspaceId === workspace) : audits;
  const sourceActions = admin && workspace ? actions.filter(a => a.workspaceId === workspace) : actions;
  const selected = useMemo(() => analyticsForScope(sourceAudits, sourceActions, availableProjects, { projectId: project, start: window.start, end: window.end }), [sourceAudits, sourceActions, availableProjects, project, window.start, window.end]);
  const m = selected.metrics;
  const label = project ? (availableProjects.find(p => p.id === project)?.name || 'Selected project') : workspace ? (workspaces.find(w => w.id === workspace)?.name || 'Selected workspace') : admin ? 'Portfolio overview' : activeWorkspace.name;
  return <div className="workspace-page ssc-v2-page ssc-v2-analytics">
    <div className="ssc-v2-hero"><div><span className="ssc-v2-kicker"><Activity size={15}/> PERFORMANCE INTELLIGENCE</span><h1>Analytics</h1><p>Understand inspection activity, compliance trends and follow-up work. Every chart reflects saved records, not estimates.</p></div><button className="ssc-v2-link" onClick={() => go('audits')}>View inspections <ArrowRight size={16}/></button></div>
    <div className="ssc-v2-filter-panel"><div className="ssc-v2-filter-label"><SlidersHorizontal size={17}/><strong>Analyse by</strong><span>{label}</span></div><div className="ssc-v2-filter-controls">
      {admin && <label>Workspace<select value={workspace} onChange={e => { setWorkspace(e.target.value); setProject(''); }}><option value="">All workspaces</option>{workspaces.map(w => <option value={w.id} key={w.id}>{w.name}</option>)}</select></label>}
      <label>Project<select value={project} onChange={e => setProject(e.target.value)}><option value="">All projects</option>{availableProjects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></label>
      <label>Time period<select value={period} onChange={e => setPeriod(e.target.value)}><option value="3">Last 3 months</option><option value="6">Last 6 months</option><option value="12">Last 12 months</option><option value="all">All records</option><option value="custom">Custom dates</option></select></label>
      {period === 'custom' && <><label>From<input type="date" value={start} max={end || todayDate} onChange={e => setStart(e.target.value)}/></label><label>To<input type="date" value={end} min={start || undefined} max={todayDate} onChange={e => setEnd(e.target.value)}/></label></>}
    </div>{invalid && <p className="ssc-v2-error" role="alert">Select both dates, with the end date after the start and no later than today.</p>}</div>
    {!invalid && <><div className="ssc-v2-stats">
      <NumberCard icon={Activity} label="Inspections" value={m.total} detail="Recorded in selected period"/>
      <NumberCard icon={CheckCircle2} label="Completion rate" value={m.completion == null ? '—' : `${m.completion}%`} detail={`${m.completed} completed inspections`}/>
      <NumberCard icon={TrendingUp} label="Average compliance" value={m.compliance == null ? '—' : `${m.compliance}%`} detail="Completed, scored inspections"/>
      <NumberCard icon={ShieldAlert} label="Open findings" value={m.open} detail={`${m.overdue} currently overdue`}/>
    </div>
    <div className="ssc-v2-analytics-grid"><ChartPanel title="Inspection activity trend" note="Monthly total and completed inspections over the selected time period">
      {selected.trend.length ? <div className="ssc-v2-chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={selected.trend} margin={{ top: 10, left: -23, right: 9 }}><CartesianGrid stroke="#edf0f5" vertical={false}/><XAxis dataKey="month" tick={axis} tickLine={false} axisLine={false}/><YAxis allowDecimals={false} tick={axis} tickLine={false} axisLine={false}/><Tooltip {...tip}/><Legend wrapperStyle={{fontSize:11}}/><Bar dataKey="total" name="Inspections" fill="#cdd7e5" radius={[5,5,0,0]}/><Bar dataKey="completed" name="Completed" fill="#df4c75" radius={[5,5,0,0]}/></BarChart></ResponsiveContainer></div> : <EmptyChart/>}
    </ChartPanel><ChartPanel title="Compliance trend" note="Average score from completed inspections, by month">
      {selected.trend.some(r => r.compliance !== null) ? <div className="ssc-v2-chart"><ResponsiveContainer width="100%" height="100%"><ComposedChart data={selected.trend} margin={{ top: 10, left: -20, right: 10 }}><CartesianGrid stroke="#edf0f5" vertical={false}/><XAxis dataKey="month" tick={axis} tickLine={false} axisLine={false}/><YAxis domain={[0,100]} tick={axis} tickLine={false} axisLine={false} unit="%"/><Tooltip {...tip} formatter={value => value == null ? 'Not recorded' : `${value}%`}/><Line dataKey="compliance" name="Average compliance" type="monotone" stroke="#d83b67" strokeWidth={3} dot={{ r:4, fill:'#fff', strokeWidth:2 }} connectNulls={false}/></ComposedChart></ResponsiveContainer></div> : <EmptyChart text="Complete a scored inspection to see compliance trends."/>}
    </ChartPanel></div>
    <div className="ssc-v2-analytics-grid"><ChartPanel title="Findings by severity" note="Current open actions compared with total recorded findings">
      {selected.severity.some(r => r.total) ? <div className="ssc-v2-chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={selected.severity} layout="vertical" margin={{ top: 6, right: 18, bottom: 0, left: 8 }}><CartesianGrid stroke="#edf0f5" horizontal={false}/><XAxis type="number" allowDecimals={false} tick={axis} tickLine={false} axisLine={false}/><YAxis type="category" dataKey="name" width={67} tick={axis} tickLine={false} axisLine={false}/><Tooltip {...tip}/><Legend wrapperStyle={{fontSize:11}}/><Bar dataKey="total" name="All findings" fill="#cdd7e5" radius={[0,4,4,0]}/><Bar dataKey="open" name="Open" fill="#dd5378" radius={[0,4,4,0]}/></BarChart></ResponsiveContainer></div> : <EmptyChart text="Findings will appear after an inspection records corrective actions."/>}
    </ChartPanel><ChartPanel title="Inspection status" note="Distribution of completed, planned and in-progress inspections">
      {selected.statuses.length ? <div className="ssc-v2-status-distribution">{selected.statuses.map(({ name, value }) => <div className="ssc-v2-progress-row" key={name}><div><strong>{name}</strong><span>{value}</span></div><div className="ssc-v2-progress-track"><span style={{width:`${Math.round(value/m.total*100)}%`}}/></div></div>)}</div> : <EmptyChart/>}
    </ChartPanel></div>
    <ChartPanel title={project ? 'Selected project performance' : 'Project comparison'} note="Compare each project's inspection volume, average scored compliance and outstanding findings">
      {selected.comparison.length ? <div className="ssc-v2-table-scroll"><table className="ssc-v2-table"><thead><tr><th>PROJECT</th><th>INSPECTIONS</th><th>COMPLIANCE</th><th>OPEN FINDINGS</th><th></th></tr></thead><tbody>{selected.comparison.map(p => <tr key={p.id}><td><strong>{p.name}</strong></td><td>{p.inspections}</td><td>{p.compliance == null ? '—' : `${p.compliance}%`}</td><td>{p.open}{p.overdue ? <small className="ssc-v2-late"> · {p.overdue} overdue</small> : null}</td><td><button className="ssc-v2-inline" onClick={() => go('sites', p.id)}>Open <ArrowRight size={14}/></button></td></tr>)}</tbody></table></div> : <EmptyChart text="Register a project to compare site performance."/>}
    </ChartPanel>
    <p className="ssc-v2-footnote"><Clock3 size={14}/> Date filters apply to recorded inspection dates and finding due dates. Historical HXC sample records are excluded; there is no fabricated trend data.</p>
    </>}
  </div>;
}
