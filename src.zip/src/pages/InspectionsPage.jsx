import React, { useMemo, useState } from 'react';
import RecordsPage from './RecordsPage.jsx';
import { ClipboardCheck, FilePlus2, Search } from 'lucide-react';
import { usePortal } from '../app/PortalContext.jsx';
import { Button, CollectionHeader, DataTable, EmptyState, FilterBar, FormModal, RecordForm } from '../components/common/WorkspaceUI.jsx';
import { Metric, Status } from '../components/common/PortalUI.jsx';
import { operational } from '../data/inspections.js';
import { metrics, today } from '../data/repository.js';
import { csv } from '../utils/reporting.js';
import HxcAudits from '../features/hxc/HxcAudits.jsx';

const field = (key, label, required = false) => ({ key, label, required });
const dateField = (key, label, required = false) => ({ key, label, type: 'date', required });
const selectField = (key, label, options, required = false) => ({ key, label, type: 'select', options, required });
const inspectionKinds = ['Draft', 'Scheduled', 'In review', 'Completed'];

/** One inspection register, one creation flow. The HXC editor remains the
 * dedicated renderer for the fixed 65-item official framework. */
export default function InspectionsPage() {
  const { activeWorkspaceId, detailId, db, workspaces, audits, actions, scopedSites, go, saveRecord, matches } = usePortal();
  const admin = activeWorkspaceId === 'admin';
  const embeddedView = detailId === 'actions' ? 'actions' : null;
  const selectedFromRoute = detailId?.startsWith('new-template-') ? detailId.slice('new-template-'.length) : null;
  const [tab, setTab] = useState('All');
  const [search, setSearch] = useState('');
  const [workspaceFilter, setWorkspaceFilter] = useState('');
  const [projectFilter, setProjectFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [creating, setCreating] = useState(Boolean(selectedFromRoute));
  const [form, setForm] = useState(null);
  const [newHxcWorkspace, setNewHxcWorkspace] = useState(null);
  const [targetWorkspace, setTargetWorkspace] = useState(admin ? '' : activeWorkspaceId);
  const [templateId, setTemplateId] = useState(selectedFromRoute || '');
  const [error, setError] = useState('');
  const cancelCreate = () => { setCreating(false); if (selectedFromRoute) go('audits'); };

  const activeWorkspaces = workspaces.filter(w => w.status !== 'Inactive');
  const availableTemplates = db.templates.filter(t => (t.workspaceIds || []).includes(targetWorkspace));
  const template = availableTemplates.find(t => t.id === templateId);
  const real = operational(audits);
  const totals = metrics(real, operational(actions));
  const filtered = useMemo(() => audits.filter(a => {
    const label = a.projectName || scopedSites.find(p => p.id === a.projectId)?.name || '';
    return (tab === 'All' || (tab === 'Draft' ? a.status !== 'Completed' : a.status === 'Completed'))
      && (!workspaceFilter || a.workspaceId === workspaceFilter)
      && (!projectFilter || a.projectId === projectFilter)
      && (!typeFilter || a.type === typeFilter)
      && (!from || (a.date && a.date >= from)) && (!to || (a.date && a.date <= to))
      && `${a.id} ${a.type || ''} ${a.inspector || ''} ${label} ${a.status || ''}`.toLowerCase().includes(search.trim().toLowerCase())
      && matches(a.id, a.type, a.inspector, label);
  }).sort((a, b) => String(b.updatedAt || b.date || '').localeCompare(String(a.updatedAt || a.date || ''))), [audits, tab, workspaceFilter, projectFilter, typeFilter, from, to, search, scopedSites, matches]);

  const open = a => go('audits', a.id);
  const existing = detailId ? audits.find(a => a.id === detailId || a.nativeId === detailId && (!admin || a.workspaceId === workspaceFilter)) : null;
  if (embeddedView) return <div className="workspace-page inspections-workspace"><button type="button" className="ssc-v2-back" onClick={() => go('audits')}>← Back to inspections</button><RecordsPage embeddedPage="actions"/></div>;
  if (detailId && !selectedFromRoute) {
    if (!existing) return <section className="panel padded"><h2>Inspection not found</h2><p>This record may have been removed or belongs to another workspace.</p><Button primary onClick={() => go('audits')}>All inspections</Button></section>;
    if (existing.source === 'hxc') return <HxcAudits key={existing.id} workspaceId={existing.workspaceId} initialAuditId={existing.nativeId} onExit={() => go('audits')} />;
    const fields = recordFields(existing.workspaceId, db);
    return <div className="workspace-page"><section className="panel padded"><CollectionHeader title={existing.type || 'General inspection'} description={`${existing.id} · ${existing.date || 'No date'} · ${existing.status || 'Draft'}`}><Button onClick={() => go('audits')}>All inspections</Button><Button primary onClick={() => setForm(existing)}>Edit inspection</Button></CollectionHeader><div className="overview-summary"><Metric name="Status" value={existing.status || 'Draft'}/><Metric name="Score" value={existing.score == null || existing.score === '' ? '—' : `${existing.score}%`}/><Metric name="Findings" value={existing.findings || 0}/></div><p><strong>Inspector:</strong> {existing.inspector || 'Not assigned'}</p><p><strong>Notes:</strong> {existing.notes || 'No notes entered.'}</p></section>{form && <RecordForm title="Edit inspection" fields={fields} initial={existing} close={() => setForm(null)} save={v => saveRecord('audits', { ...v, workspaceId: existing.workspaceId })}/>}</div>;
  }
  if (newHxcWorkspace) return <HxcAudits key={`new-${newHxcWorkspace}`} workspaceId={newHxcWorkspace} createNew onExit={() => { setNewHxcWorkspace(null); if (selectedFromRoute) go('audits'); }} />;
  const start = () => {
    if (!targetWorkspace) { setError('Select a client workspace.'); return; }
    if (!template) { setError('Choose an inspection template assigned to this workspace.'); return; }
    setError(''); setCreating(false);
    if (template.kind === 'hxc' || template.id === 'hxc') setNewHxcWorkspace(targetWorkspace);
    else setForm({ workspaceId: targetWorkspace, templateId: template.id, type: template.name, status: 'Draft', date: today(), findings: 0, score: '' });
  };
  const generalFields = recordFields(form?.workspaceId || targetWorkspace, db);
  const columns = [
    { label: 'Inspection', render: a => <><strong>{a.projectName || scopedSites.find(p => p.id === a.projectId)?.name || a.type || 'Untitled inspection'}</strong><small>{a.source === 'hxc' ? a.nativeId : a.id}{a.demo ? ' · SAMPLE (excluded from KPIs)' : ''}</small></> },
    ...(admin ? [{ label: 'Workspace', render: a => workspaces.find(w => w.id === a.workspaceId)?.name || (a.workspaceId === 'admin' ? 'Legacy archive' : 'Unassigned') }] : []),
    { label: 'Template', render: a => a.source === 'hxc' ? 'HXC Site Compliance Audit' : a.type || 'General inspection' },
    { label: 'Inspector', key: 'inspector' },
    { label: 'Date', key: 'date' },
    { label: 'Status', render: a => <Status text={a.status || 'Draft'}/> },
    { label: 'Score', render: a => a.status !== 'Completed' || a.score == null || a.score === '' ? '—' : `${a.score}%` },
    { label: 'Actions', render: a => <Button onClick={() => open(a)}>{a.source === 'hxc' ? 'Open HXC checklist' : 'View / edit'}</Button> },
  ];
  return <div className="workspace-page unified-inspections inspections-workspace">
    <section className="panel padded"><CollectionHeader title="Inspections" description="HXC compliance checklists and general inspections share one searchable register." onAdd={() => { setTargetWorkspace(admin ? '' : activeWorkspaceId); setTemplateId(db.templates.find(t => (t.workspaceIds || []).includes(admin ? '' : activeWorkspaceId))?.id || ''); setError(''); setCreating(true); }} label="Create inspection" />
      <div className="overview-summary inspection-summary"><Metric name="All inspections" value={totals.total} detail="Total records in this workspace"/><Metric name="Completed inspections" value={totals.completed} detail="Ready for review and reporting"/><Metric name="In progress" value={totals.pending} detail="Draft or awaiting completion"/></div>
      <div className="inspection-tabs" role="group" aria-label="Inspection status">{[['All','All inspections'],['Draft','Draft / in progress'],['Completed','Completed']].map(([v,label]) => <button type="button" key={v} className={tab === v ? 'active' : ''} aria-pressed={tab === v} onClick={() => setTab(v)}>{label}</button>)}</div>
      <FilterBar><label>Search <span className="inspection-search"><Search size={15}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Reference, project, inspector"/></span></label>{admin && <label>Workspace<select value={workspaceFilter} onChange={e => { setWorkspaceFilter(e.target.value); setProjectFilter(''); }}><option value="">All workspaces</option><option value="admin">Legacy HXC archive</option>{workspaces.map(w => <option value={w.id} key={w.id}>{w.name}</option>)}</select></label>}<label>Project<select value={projectFilter} onChange={e => setProjectFilter(e.target.value)}><option value="">All projects</option>{scopedSites.filter(p => !workspaceFilter || p.workspaceId === workspaceFilter).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></label><label>Inspection type<select value={typeFilter} onChange={e => setTypeFilter(e.target.value)}><option value="">All types</option>{[...new Set(audits.map(a => a.type).filter(Boolean))].sort().map(t => <option key={t}>{t}</option>)}</select></label><label>From<input type="date" value={from} onChange={e => setFrom(e.target.value)}/></label><label>To<input type="date" value={to} onChange={e => setTo(e.target.value)}/></label></FilterBar>
      <div className="actions-row"><Button onClick={() => csv('ssc-unified-inspections.csv', [['Workspace', 'Reference', 'Template', 'Project', 'Inspector', 'Date', 'Status', 'Score', 'Sample'], ...filtered.map(a => [a.workspaceId, a.nativeId, a.source === 'hxc' ? 'HXC Site Compliance Audit' : a.type, a.projectName || scopedSites.find(p => p.id === a.projectId)?.name || '', a.inspector, a.date, a.status, a.status === 'Completed' ? a.score : '', a.demo ? 'Yes' : 'No'])])}>Export filtered CSV</Button></div>
      <DataTable columns={columns} rows={filtered} empty={<EmptyState title="No matching inspections" description="Adjust the filters or create an inspection using a registered template."/>}/>
      <p className="workspace-note">HXC audits use their existing 65-item editor, scoring, photographs and signatures. All inspections appear here; sample audits are clearly labelled and excluded from performance figures. Records remain browser-local.</p>
    </section>
    {creating && <FormModal title="Create inspection" close={cancelCreate}><div className="dialog-body"><p>Choose the workspace and inspection template. HXC opens the full compliance checklist; other templates use the general inspection form.</p><div className="workspace-form-grid">{admin && <label className="field">Workspace *<select value={targetWorkspace} onChange={e => { setTargetWorkspace(e.target.value); setTemplateId(db.templates.find(t => (t.workspaceIds || []).includes(e.target.value))?.id || ''); }}><option value="">Select workspace…</option>{activeWorkspaces.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}</select></label>}<label className="field">Inspection template *<select value={templateId} onChange={e => setTemplateId(e.target.value)}><option value="">Select template…</option>{availableTemplates.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}</select></label></div>{targetWorkspace && !availableTemplates.length && <p className="workspace-note">No templates are assigned to this workspace. {admin ? 'Assign one in Admin → Manage Templates.' : 'Please ask an administrator to assign a template.'}</p>}{template?.kind === 'hxc' && <p className="workspace-note"><ClipboardCheck size={15}/> HXC compliance · 65 requirements · 10 sections · evidence, sign-off and PDF export</p>}{template && template.kind !== 'hxc' && <p className="workspace-note"><FilePlus2 size={15}/> General inspection record · project, inspector, findings, notes and score</p>}{error && <p role="alert" className="error">{error}</p>}<div className="dialog-footer"><Button onClick={cancelCreate}>Cancel</Button><Button primary onClick={start}>Continue</Button></div></div></FormModal>}
    {form && <RecordForm title={form.id ? 'Edit inspection' : 'New inspection'} fields={generalFields} initial={form} close={() => { setForm(null); if (selectedFromRoute) go('audits'); }} save={v => saveRecord('audits', v)}/>}
  </div>;
}
function recordFields(workspaceId, db) {
  const projects = db.projects.filter(p => p.workspaceId === workspaceId && p.status !== 'Archived');
  return [selectField('projectId', 'Project', projects.map(p => ({ value: p.id, label: p.name })), true),
    field('inspector', 'Inspector', true), dateField('date', 'Inspection date', true),
    selectField('status', 'Status', inspectionKinds, true),
    { ...field('score', 'Recorded compliance score (0–100)'), type: 'number', min: 0, max: 100 },
    { ...field('findings', 'Finding count'), type: 'number', min: 0, max: 10000 },
    { ...field('notes', 'Inspection notes'), type: 'textarea', wide: true }];
}
