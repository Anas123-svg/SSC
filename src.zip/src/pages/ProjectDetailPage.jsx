import React, { useMemo, useState } from 'react';
import { ArrowLeft, Download, FolderOpen, Plus } from 'lucide-react';
import { usePortal } from '../app/PortalContext.jsx';
import { Button, CollectionHeader, DataTable, EmptyState, RecordForm } from '../components/common/WorkspaceUI.jsx';
import { Metric, Status } from '../components/common/PortalUI.jsx';
import { metrics, isOpen, isOverdue, trendData, today } from '../data/repository.js';
import { operational } from '../data/inspections.js';
import { projectRecords } from '../data/projectScope.js';
import { RecordCharts } from './ReportingPage.jsx';
import ReportsPage from './ReportsPage.jsx';

export const PROJECT_SECTIONS = ['overview', 'inspections', 'actions', 'insights', 'reports', 'documents'];
const sections = [
  ['overview', 'Overview'], ['inspections', 'Inspections'], ['actions', 'Corrective actions'],
  ['insights', 'Insights'], ['reports', 'Reports'], ['documents', 'Documents'],
];
const field = (key, label, required = false) => ({ key, label, required });
const select = (key, label, options, required = false) => ({ key, label, type: 'select', options, required });
const area = (key, label) => ({ key, label, type: 'textarea', wide: true });
const date = (key, label, required = false) => ({ key, label, type: 'date', required });

/** A project is a scope for inspections, evidence, findings and reports, not another tenant.
 * All records are matched by projectId; neither project names nor route strings grant access.
 */
export default function ProjectDetailPage({ project, onEdit }) {
  const ctx = usePortal();
  const { subview, activeWorkspaceId, scoped, audits, actions, saveRecord, go, workspaces, db } = ctx;
  const section = PROJECT_SECTIONS.includes(subview) ? subview : 'overview';
  const [editingAction, setEditingAction] = useState(null);
  const [editingDocument, setEditingDocument] = useState(null);
  const [documentCategory, setDocumentCategory] = useState('');
  const projectAudits = useMemo(() => projectRecords(audits, project), [audits, project.id]);
  const projectActions = useMemo(() => projectRecords(actions, project), [actions, project.id]);
  const projectDocuments = projectRecords(scoped('documents'), project).filter(r => !documentCategory || r.category === documentCategory);
  const performance = metrics(operational(projectAudits), operational(projectActions));
  const move = next => go('sites', project.id, activeWorkspaceId, next === 'overview' ? null : next);
  const openInspection = r => go('audits', r.id);
  const openFinding = r => r.source === 'hxc' ? go('audits', r.inspectionId) : setEditingAction(r);
  const download = file => {
    if (!file?.data) return;
    const a = document.createElement('a'); a.href = file.data; a.download = file.name || 'document'; a.click();
  };
  const actionFields = [
    field('title', 'Finding / description', true),
    select('inspectionId', 'Related inspection', [{ value: '', label: 'Not linked' }, ...projectAudits.filter(r => r.source !== 'hxc').map(r => ({ value: r.id, label: `${r.nativeId || r.id} · ${r.type}` }))]),
    select('priority', 'Severity', ['Low', 'Medium', 'High', 'Critical'], true),
    field('assigned', 'Responsible person', true), date('due', 'Due date', true),
    select('status', 'Status', ['Open', 'In Progress', 'Resolved', 'Closed'], true),
    area('notes', 'Progress notes'), area('evidence', 'Completion evidence / verification reference'),
    { key: 'evidenceFile', label: 'Completion attachment (maximum 750 KB)', type: 'file' },
  ];
  const documentFields = [
    field('name', 'Document title', true),
    select('category', 'Category', ['Safety documentation', 'Method statements', 'Inspection reports', 'Certificates', 'Training records', 'Other'], true),
    field('reference', 'Reference / revision'), area('description', 'Description'),
    { key: 'file', label: 'File (maximum 750 KB)', type: 'file', hint: 'Stored in your browser only, not uploaded to a secure server.' },
  ];
  const saveAction = v => saveRecord('actions', { ...v, workspaceId: project.workspaceId, projectId: project.id });
  const saveDocument = v => {
    if (!v.file && !editingDocument?.file) throw new Error('Select a document file.');
    saveRecord('documents', { ...v, workspaceId: project.workspaceId, projectId: project.id });
  };
  const inspectionColumns = [
    { label: 'Inspection', render: r => <><strong>{r.type}</strong><small>{r.nativeId || r.id}</small></> },
    { label: 'Date', key: 'date' }, { label: 'Inspector', key: 'inspector' },
    { label: 'Status', render: r => <Status text={r.status || 'Draft'}/> },
    { label: 'Score', render: r => r.status === 'Completed' && r.score != null ? `${r.score}%` : '—' },
    { label: 'Open', render: r => <Button onClick={() => openInspection(r)}>View inspection</Button> },
  ];
  const actionColumns = [
    { label: 'Finding', render: r => <><strong>{r.title || r.finding}</strong><small>{r.nativeId || r.id}</small></> },
    { label: 'Severity', key: 'priority' }, { label: 'Responsible', key: 'assigned' }, { label: 'Due', key: 'due' },
    { label: 'Status', render: r => <Status text={isOverdue(r) ? 'Overdue' : r.status}/> },
    { label: 'Action', render: r => <Button onClick={() => openFinding(r)}>{r.source === 'hxc' ? 'Open HXC checklist' : 'Update / close'}</Button> },
  ];
  const documentColumns = [
    { label: 'Document', render: r => <><strong>{r.name}</strong><small>{r.reference || r.id}</small></> },
    { label: 'Category', key: 'category' }, { label: 'Description', key: 'description' },
    { label: 'Actions', render: r => <div className="row-actions"><Button onClick={() => download(r.file)} disabled={!r.file?.data}><Download size={14}/> Download</Button><Button onClick={() => setEditingDocument(r)}>Edit details</Button></div> },
  ];
  const latest = [...projectAudits].sort((a, b) => String(b.date || '').localeCompare(String(a.date || ''))).at(0);
  return <div className="workspace-page project-detail-page">
    <section className="panel padded project-heading">
      <div className="project-breadcrumb"><button type="button" onClick={() => go('sites')}><ArrowLeft size={15}/> All projects</button><span>/</span><strong>{project.name}</strong></div>
      <CollectionHeader title={project.name} description={[project.reference, project.address, workspaces.find(w => w.id === project.workspaceId)?.name, project.manager].filter(Boolean).join(' · ')}>
        <Status text={project.status || 'Active'}/><Button onClick={onEdit}>Edit project</Button>
      </CollectionHeader>
      <nav className="project-section-nav" aria-label="Project sections">
        {sections.map(([id, label]) => <button type="button" key={id} className={section === id ? 'active' : ''} aria-current={section === id ? 'page' : undefined} onClick={() => move(id)}>{label}</button>)}
      </nav>
    </section>
    {section === 'overview' && <>
      <div className="overview-summary"><Metric name="Inspections" value={performance.total}/><Metric name="Completed" value={performance.completed}/><Metric name="Average compliance" value={performance.compliance == null ? '—' : `${performance.compliance}%`}/><Metric name="Open findings" value={performance.open}/><Metric name="Overdue" value={performance.overdue}/></div>
      <section className="panel padded"><CollectionHeader title="Project overview" description="Project-specific safety records and upcoming work."/><p>{project.description || 'No description added.'}</p><div className="project-overview-grid"><div><small>Site address</small><strong>{project.address || 'Not provided'}</strong></div><div><small>Project manager</small><strong>{project.manager || 'Not assigned'}</strong></div><div><small>Start date</small><strong>{project.start || 'Not set'}</strong></div><div><small>Expected completion</small><strong>{project.end || 'Not set'}</strong></div><div><small>Latest inspection</small><strong>{latest?.date || 'None recorded'}</strong></div></div></section>
      <div className="workspace-two-columns"><section className="panel padded"><CollectionHeader title="Recent inspections"><Button onClick={() => move('inspections')}>View all</Button></CollectionHeader><DataTable rows={projectAudits.slice().sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))).slice(0,5)} columns={inspectionColumns}/></section><section className="panel padded"><CollectionHeader title="Outstanding findings"><Button onClick={() => move('actions')}>View all</Button></CollectionHeader><DataTable rows={projectActions.filter(r=>isOpen(r)).slice(0,5)} columns={actionColumns}/></section></div>
    </>}
    {section === 'inspections' && <section className="panel padded"><CollectionHeader title="Project inspections" description="HXC audits and general inspections linked to this construction project."><Button onClick={() => go('audits')}>Open inspection register</Button></CollectionHeader><DataTable rows={projectAudits} columns={inspectionColumns} empty={<EmptyState title="No project inspections" description="Start an inspection in the register and associate it with this project."/>}/></section>}
    {section === 'actions' && <section className="panel padded"><CollectionHeader title="Project corrective actions" description="Findings from general inspections and HXC checklists. HXC findings are edited in their original audits." onAdd={() => setEditingAction({ workspaceId: project.workspaceId, projectId: project.id, status: 'Open', priority: 'Medium', due: today() })} label="Create finding"/><DataTable rows={projectActions} columns={actionColumns} empty={<EmptyState title="No corrective actions" description="Any findings linked to this project appear here."/>}/></section>}
    {section === 'insights' && <><div className="overview-summary"><Metric name="Recorded inspections" value={performance.total}/><Metric name="Completed" value={performance.completed}/><Metric name="Compliance" value={performance.compliance == null ? '—' : `${performance.compliance}%`}/><Metric name="Open actions" value={performance.open} detail={`${performance.overdue} overdue`}/></div><RecordCharts data={trendData(operational(projectAudits))}/><section className="panel padded"><CollectionHeader title="Project findings by severity"/><DataTable rows={['Low','Medium','High','Critical'].map(priority=>({id:priority,total:projectActions.filter(a=>a.priority===priority).length,open:projectActions.filter(a=>a.priority===priority && isOpen(a)).length}))} columns={[{label:'Severity',key:'id'},{label:'Total',key:'total'},{label:'Open',key:'open'}]}/></section></>}
    {section === 'reports' && <ReportsPage projectId={project.id} />}
    {section === 'documents' && <section className="panel padded"><CollectionHeader title="Project documents" description="Files and evidence specifically attached to this project. Small uploads remain browser-local." onAdd={() => setEditingDocument({ workspaceId: project.workspaceId, projectId: project.id, category: 'Inspection reports' })} label="Add document"/><label className="project-document-filter">Category <select value={documentCategory} onChange={e=>setDocumentCategory(e.target.value)}><option value="">All categories</option>{[...new Set(projectRecords(scoped('documents'), project).map(r=>r.category).filter(Boolean))].sort().map(c=><option key={c} value={c}>{c}</option>)}</select></label><DataTable rows={projectDocuments} columns={documentColumns} empty={<EmptyState title="No project documents" description="Add drawings, method statements, inspection reports or supporting files here." action={<Button onClick={() => setEditingDocument({ workspaceId: project.workspaceId, projectId: project.id })}><Plus size={15}/> Add a document</Button>}/>}/></section>}
    {editingAction && <RecordForm title={editingAction.id ? 'Update project finding' : 'Create project finding'} fields={actionFields} initial={editingAction} save={saveAction} close={() => setEditingAction(null)}/>}
    {editingDocument && <RecordForm title={editingDocument.id ? 'Edit project document' : 'Add project document'} fields={documentFields} initial={editingDocument} save={saveDocument} close={() => setEditingDocument(null)}/>}
  </div>;
}
