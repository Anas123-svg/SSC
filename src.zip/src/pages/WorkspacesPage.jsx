import React, { useState } from 'react';
import { usePortal } from '../app/PortalContext.jsx';
import { DataTable, Button, RecordForm, CollectionHeader, FilterBar } from '../components/common/WorkspaceUI.jsx';
import { workspaceFields } from '../components/dialogs/CreateWorkspaceDialog.jsx';
import { Status } from '../components/common/PortalUI.jsx';
export default function WorkspacesPage() {
 const { db, workspaces, matches, go, setModal, saveRecord, setToast } = usePortal();
 const [editing,setEditing]=useState(null),[modules,setModules]=useState(false),[status,setStatus]=useState('');
 const fields=workspaceFields.filter(f=>f.key!=='client').map(f=>f.key==='modules'?f:f);
 const toggleStatus = w => { try { saveRecord('workspaces',{...w,status:w.status==='Active'?'Inactive':'Active'}); } catch (e) { setToast(e.message); } };
 fields.splice(1,0,{key:'clientId',label:'Linked client / company',type:'select',required:true,options:db.clients.map(c=>({value:c.id,label:c.name}))});
 return <section className="panel padded"><CollectionHeader title="Client workspaces" description="A workspace groups projects for a client. Admin is a separate global workspace." onAdd={()=>setModal({kind:'new-workspace'})} label="Add workspace"/>
 <FilterBar><label>Status<select value={status} onChange={e=>setStatus(e.target.value)}><option value="">All workspaces</option><option>Active</option><option>Inactive</option></select></label></FilterBar>
 <DataTable rows={workspaces.filter(w=>matches(w.name,w.client,w.contact)&&(!status||w.status===status))} columns={[
 {label:'Workspace',render:w=><><strong>{w.name}</strong><small>{w.description||w.id}</small></>},{label:'Client / company',key:'client'},
 {label:'Projects',render:w=>db.projects.filter(p=>p.workspaceId===w.id).length},{label:'Modules',render:w=>w.modules.length},
 {label:'Status',render:w=><Status text={w.status}/>},
 {label:'Actions',render:w=><div className="row-actions"><Button disabled={w.status==='Inactive'} onClick={()=>go('overview',null,w.id)}>View Workspace</Button><Button disabled={w.status==='Inactive'} onClick={()=>go('sites',null,w.id)}>Projects</Button><Button onClick={()=>{setModules(false);setEditing(w);}}>Edit</Button><Button onClick={()=>{setModules(true);setEditing(w);}}>Manage Modules</Button><Button onClick={()=>toggleStatus(w)}>{w.status==='Active'?'Deactivate':'Activate'}</Button></div>},
 ]}/>
 {editing&&<RecordForm title={modules?'Manage Modules — '+editing.name:'Edit workspace'} fields={modules?fields.filter(f=>f.key==='modules'):fields} initial={editing} close={()=>setEditing(null)} save={v=>saveRecord('workspaces',v)}><p className="workspace-note">Disabling a module hides its navigation and blocks its route. Stored records are retained.</p></RecordForm>}
 </section>;
}

