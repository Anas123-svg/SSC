import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './app/App.jsx';
import './styles/styles.css';
import './styles/refinement.css';
import './styles/ssc-theme.css';
import './styles/workspace-sidebar.css';
import './styles/workspace-pages.css';

createRoot(document.getElementById('root')).render(<React.StrictMode><App /></React.StrictMode>);
import './styles/workspace-pages.css';

import './styles/dashboard-reports.css';

import './styles/ssc-v2-pages.css';
